package _mall;

public interface MenuCommand {
	public void init();
	public boolean update();
}
